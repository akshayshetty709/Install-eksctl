# Demo Project: Practise 2 Jenkins + 2 EC2 (before doing Bikerz)

A tiny app and a tiny QA job, set up the **same way** as Bikerz. Do this once, end to end, and the Bikerz project will feel familiar.

**Time:** about 2 hours. **Cost:** two small EC2 instances for a few hours (terminate them at the end, see part 12).

## 0. What you will build

```
 You: git push
        │
        ▼
 ┌──────────────── EC2-A ─────────────────┐            ┌──────────── EC2-B ────────────┐
 │ DevOps Jenkins :8080                   │            │ QA Jenkins :8080              │
 │   job: demo-deploy                     │  trigger   │   job: demo-qa-job            │
 │     ├─ ssh to ubuntu@127.0.0.1         │ ─────────► │     ├─ curl tests on the app  │
 │     ├─ git clone demo-app              │ (API token)│     └─ JUnit test report      │
 │     ├─ docker compose build / up       │            └───────────────┬───────────────┘
 │     ├─ health check (+ auto rollback)  │                            │ HTTP :8085
 │     └─ trigger QA job                  │ ◄──────────────────────────┘
 │ Docker: demo-app  :8085                │
 └────────────────────────────────────────┘
```

| | Project | GitHub repo | Machine | Jenkins job |
|---|---------|-------------|---------|-------------|
| Deploy side | `demo-app` | `demo-app` | **EC2-A** (DevOps Jenkins + the app server) | `demo-deploy` |
| QA side | `demo-qa` | `demo-qa` | **EC2-B** (QA Jenkins) | `demo-qa-job` |

To keep it to **two EC2s**, EC2-A is both the DevOps Jenkins and the server the app is deployed to. Jenkins still deploys by **SSH** (to `ubuntu@127.0.0.1`), exactly like it would to a separate server. In Bikerz the app server is simply another machine; the pipeline is identical.

**What you will practise**
- Launch EC2s, security groups, Elastic IPs
- Install Jenkins (twice), Docker, Java
- Jenkins plugins, credentials, Pipeline-from-SCM jobs, parameters
- Deploy with Docker Compose, health check, **automatic rollback**
- Run a QA job on a second Jenkins, read a test report
- Trigger one Jenkins from another with an API token

**Names used in this guide (keep them exactly, the files already use them)**

| Thing | Name |
|-------|------|
| SSH credential on DevOps Jenkins | `demo-server-ssh` |
| QA API credential on DevOps Jenkins | `demo-qa-api` |
| QA user on QA Jenkins | `demo-trigger` |
| Deploy job / QA job | `demo-deploy` / `demo-qa-job` |
| App port | `8085` |

Write down as you go (you will need them):

```
GitHub user : ______________________
EC2-A IP    : ______________________   (DevOps Jenkins + app)
EC2-B IP    : ______________________   (QA Jenkins)
```

---

## 1. Your laptop and GitHub

### 1.1 Install Git
`git --version` must work. (Ubuntu: `sudo apt-get install -y git`; Windows: install *Git for Windows*; macOS: `xcode-select --install`.)

### 1.2 GitHub account and SSH key (for pushing)
1. Create a free account at github.com if you do not have one.
2. Create an SSH key and add it:

   ```bash
   ssh-keygen -t ed25519 -C "your-email@example.com"      # press Enter for all questions
   cat ~/.ssh/id_ed25519.pub
   ```
   GitHub → profile picture → **Settings → SSH and GPG keys → New SSH key** → paste → **Add SSH key**.
3. Test: `ssh -T git@github.com` → *"Hi <user>! You've successfully authenticated"*.

### 1.3 Create the two repositories
1. GitHub → **+ → New repository** → name `demo-app` → **Public** → *no* README/.gitignore → **Create repository**.
2. Same for `demo-qa` (**Public**).

(They are public on purpose, so the servers can clone them over HTTPS **without any key**. Bikerz uses private repos and SSH keys; you will add that later.)

### 1.4 Put your GitHub username into the deploy Jenkinsfile
Open `demo-app/Jenkinsfile` and change:

```groovy
REPO = 'https://github.com/<YOUR-GITHUB-USER>/demo-app.git'
```
to your real username, for example `https://github.com/macha123/demo-app.git`.

### 1.5 Push both projects

```bash
cd demo-app
git init
git add .
git commit -m "demo-app first version"
git branch -M main
git remote add origin git@github.com:<YOUR-GITHUB-USER>/demo-app.git
git push -u origin main

cd ../demo-qa
git init
git add .
git commit -m "demo-qa first version"
git branch -M main
git remote add origin git@github.com:<YOUR-GITHUB-USER>/demo-qa.git
git push -u origin main
```

### 1.4b (optional) Run the app on your laptop first
If you have Node 18+: `cd demo-app && node server.js`, open `http://localhost:3000`.
Then, in another terminal: `cd demo-qa && APP_URL=http://localhost:3000 ./tests/run_tests.sh` → 6 PASS.

---

## 2. AWS: launch the two EC2 instances

### 2.1 Key pair (once)
AWS Console → **EC2** → **Key Pairs** → **Create key pair** → name `demo-key`, type RSA, format `.pem` → **Create**. The file downloads. Keep it safe, then:

```bash
chmod 400 ~/Downloads/demo-key.pem
```

### 2.2 Launch EC2-A (DevOps Jenkins + app server)
1. EC2 → **Launch instance**.
2. Name: `demo-ec2-a-devops`.
3. AMI: **Ubuntu Server 22.04 LTS** (x86_64).
4. Instance type: **t3.medium** (2 vCPU / 4 GB). `t3.small` also works for the demo.
5. Key pair: `demo-key`.
6. Network settings → **Create security group** named `demo-a-sg`, inbound rules:

   | Type | Port | Source |
   |------|------|--------|
   | SSH | 22 | **My IP** |
   | Custom TCP | 8080 | **My IP** (Jenkins UI) |
   | Custom TCP | 8085 | **My IP** (the demo app) |

   (You will add two more rules later, in 2.5.)
7. Storage: **20 GB** gp3.
8. **Launch instance**.

### 2.3 Launch EC2-B (QA Jenkins)
Same as above, but:
- Name: `demo-ec2-b-qa`
- Type: **t3.small** (2 GB) is enough
- Security group `demo-b-sg`, inbound rules: SSH 22 from **My IP**, Custom TCP **8080** from **My IP**.

### 2.4 Elastic IPs (so addresses do not change when you stop/start)
For **each** instance:
1. EC2 → **Elastic IPs** → **Allocate Elastic IP address** → **Allocate**.
2. Select it → **Actions → Associate Elastic IP address** → choose the instance → **Associate**.
3. Write the IPs in your notes (EC2-A IP, EC2-B IP).

### 2.5 Allow the two servers to talk to each other
1. **`demo-a-sg`** → Inbound rules → **Edit** → add Custom TCP **8085** from `<EC2-B IP>/32` (the QA tests call the app).
2. **`demo-b-sg`** → Inbound rules → **Edit** → add Custom TCP **8080** from `<EC2-A IP>/32` (DevOps Jenkins triggers the QA job).

(`/32` means exactly that one address.)

---

## 3. EC2-A: install and open the DevOps Jenkins

### 3.1 Log in and run the setup script
```bash
ssh -i ~/Downloads/demo-key.pem ubuntu@<EC2-A IP>
```
First time it asks *"Are you sure you want to continue connecting?"* → type `yes`.

On EC2-A:

```bash
git clone https://github.com/<YOUR-GITHUB-USER>/demo-app.git
cd demo-app
bash scripts/setup-devops-ec2.sh
```

The script (takes about 5 minutes) installs swap, Java 17, Docker, git and Jenkins, creates an SSH key for the `jenkins` user, allows it to log in to `ubuntu@127.0.0.1`, and tests that. At the end it prints:
- the **initial Jenkins admin password** → copy it
- the **private key** between the dashed lines → you need it in step 3.4

Finally **log out and log in again** (so the docker group applies):

```bash
exit
ssh -i ~/Downloads/demo-key.pem ubuntu@<EC2-A IP>
docker ps        # must work without "permission denied"
```

### 3.2 First login to Jenkins
1. Browser: `http://<EC2-A IP>:8080`
2. Paste the initial admin password → **Continue**.
3. **Install suggested plugins** → wait until finished.
4. Create First Admin User: username `admin`, a password you will remember, name, e-mail → **Save and Continue**.
5. Jenkins URL: `http://<EC2-A IP>:8080/` → **Save and Finish** → **Start using Jenkins**.

### 3.3 Install the SSH Agent plugin
1. **Manage Jenkins** → **Plugins** → **Available plugins**.
2. Search `SSH Agent` → tick **SSH Agent** → **Install**.
3. Tick **Restart Jenkins when installation is complete and no jobs are running**. Wait a minute and log in again.

### 3.4 Add the SSH credential `demo-server-ssh`
1. **Manage Jenkins** → **Credentials** → **System** → **Global credentials (unrestricted)** → **Add Credentials**.
2. Fill in:
   - Kind: **SSH Username with private key**
   - Scope: Global
   - ID: **`demo-server-ssh`**
   - Description: `ssh to demo server`
   - Username: **`ubuntu`**
   - Private Key → **Enter directly** → **Add** → paste the private key printed by the script (from `-----BEGIN OPENSSH PRIVATE KEY-----` to `-----END OPENSSH PRIVATE KEY-----`, including both lines).
   - If you lost it: on EC2-A run `sudo cat /var/lib/jenkins/.ssh/id_ed25519`.
3. **Create**.

---

## 4. Create the `demo-deploy` job and deploy

### 4.1 Create the job
1. Jenkins home → **New Item** → name **`demo-deploy`** → **Pipeline** → **OK**.
2. Scroll to **Pipeline**:
   - Definition: **Pipeline script from SCM**
   - SCM: **Git**
   - Repository URL: `https://github.com/<YOUR-GITHUB-USER>/demo-app.git`
   - Credentials: **- none -** (public repo)
   - Branch Specifier: `*/main`
   - Script Path: `Jenkinsfile`
3. **Save**.

### 4.2 First build
1. Click **Build Now**. The first build also registers the parameters (`BRANCH`, `HEALTH_URL`, ...). It uses the defaults, which is fine: `TRIGGER_QA` is off.
2. Click the build number (#1) → **Console Output**. Watch the stages: *Check settings → Clone new release → Build and switch*.
3. Success ends with `Finished: SUCCESS`.

If it fails, see part 11.

### 4.3 Look at your app
- Browser: `http://<EC2-A IP>:8085` → "Hello from Demo App", version 1.0.0.
- `http://<EC2-A IP>:8085/health` → `{"status":"ok"}`
- `http://<EC2-A IP>:8085/api/greet?name=Macha`

On EC2-A:

```bash
cd /home/ubuntu/demo-app
docker compose ps
docker compose logs --tail=20
```

From now on you use **Build with Parameters** instead of Build Now.

---

## 5. Practice: change, redeploy, break, roll back

### 5.1 Practice A: ship a new version
1. On your laptop edit `demo-app/VERSION` → `1.1.0`. Optionally edit the text in `server.js`.
2. `git add . && git commit -m "version 1.1.0" && git push`
3. Jenkins → `demo-deploy` → **Build with Parameters** → **Build**.
4. Refresh `http://<EC2-A IP>:8085` → version **1.1.0**.

What happened: Jenkins cloned the new code into `demo-app_new`, built it, stopped the old one, moved folders (`demo-app` → `demo-app_old`), started the new one and checked `/health`.

### 5.2 Practice B: force a failed deployment and watch the automatic rollback
1. **Build with Parameters** → set `HEALTH_URL` to `http://localhost:8085/wrong-path` → **Build**.
2. The new version starts, but the health check keeps failing (404) for about 60 seconds. Console shows `Health check failed. Rolling back...`, the build turns red.
3. Open `http://<EC2-A IP>:8085`: the app is **still working**, running the previous version. That is the rollback.

### 5.3 Practice C: manual rollback (what to do if the app is bad but health is fine)
```bash
ssh -i ~/Downloads/demo-key.pem ubuntu@<EC2-A IP>
cd /home/ubuntu/demo-app && docker compose down
mv /home/ubuntu/demo-app /home/ubuntu/demo-app_bad
mv /home/ubuntu/demo-app_old /home/ubuntu/demo-app
cd /home/ubuntu/demo-app && docker compose up -d --build
```

---

## 6. EC2-B: install and open the QA Jenkins

### 6.1 Setup script
```bash
ssh -i ~/Downloads/demo-key.pem ubuntu@<EC2-B IP>
git clone https://github.com/<YOUR-GITHUB-USER>/demo-qa.git
cd demo-qa
bash scripts/setup-qa-ec2.sh
```
Copy the **initial admin password** it prints.

Check that EC2-B can reach the app on EC2-A:

```bash
curl -fsS http://<EC2-A IP>:8085/health
```
You must see `{"status":"ok"}`. If it hangs, redo step 2.5 (rule 1).

### 6.2 First login to the QA Jenkins
1. Browser: `http://<EC2-B IP>:8080`
2. Initial admin password → **Install suggested plugins** → create admin user → Jenkins URL `http://<EC2-B IP>:8080/` → **Save and Finish**.

(No extra plugins are needed. The suggested plugins include Git, Pipeline and JUnit.)

### 6.3 Create the job `demo-qa-job`
1. **New Item** → name **`demo-qa-job`** → **Pipeline** → OK.
2. **Pipeline** → *Pipeline script from SCM* → Git → Repository URL `https://github.com/<YOUR-GITHUB-USER>/demo-qa.git` → Credentials: none → Branch `*/main` → Script Path `Jenkinsfile` → **Save**.

### 6.4 Run it by hand
1. **Build Now** (first run registers the parameters; it will stop with `APP_URL still contains the placeholder`, which is expected).
2. **Build with Parameters**:
   - `APP_URL` = `http://<EC2-A IP>:8085`
   - `SEND_EMAIL` unticked
3. **Build**. Stages: *Checkout → Check application is reachable → Run tests*.
4. Console: six `PASS` lines. On the build page click **Test Result**: 6 tests, 0 failures. **Artifacts** has `reports/junit.xml`.

---

## 7. Practice D: see a failing test

1. On your laptop in `demo-qa/tests/run_tests.sh` change `'Hello from Demo App'` in `t_home_page` to `'Goodbye'`, then commit and push.
2. QA Jenkins → `demo-qa-job` → **Build with Parameters** → **Build**.
3. The build is **UNSTABLE/red**, console shows `FAIL home page shows greeting`, **Test Result** lists the failed test.
4. Change it back, push, run again → green.

---

## 8. Connect the two Jenkins servers

### 8.1 QA Jenkins: create the trigger user and API token (on EC2-B Jenkins)
1. **Manage Jenkins** → **Users** → **Create User**: username **`demo-trigger`**, password (choose one), full name `Demo Trigger` → **Create User**.
2. Log out, then log in as **`demo-trigger`**.
3. Click the user name (top right) → **Security** → **API Token** → **Add new Token** → name `devops` → **Generate**.
4. **Copy the token now.** It is shown only once. (Paste it into a notes file for the next steps.)
5. Log out and log in as `admin` again.

(By default any logged-in user can build jobs, which is enough for the demo. Bikerz README explains tighter permissions.)

### 8.2 Test the trigger by hand (from EC2-A)
On EC2-A:

```bash
curl -i -X POST -u "demo-trigger:<API_TOKEN>" \
  --data-urlencode "APP_URL=http://<EC2-A IP>:8085" \
  "http://<EC2-B IP>:8080/job/demo-qa-job/buildWithParameters"
```
`HTTP/1.1 201 Created` means it worked: a new build appears in the QA Jenkins within seconds.

| Code | Meaning |
|------|---------|
| connection timeout | `demo-b-sg` is missing the 8080 rule from `<EC2-A IP>/32` (step 2.5) |
| 401 | wrong user name or token |
| 403 | the user cannot build; or a "crumb" problem (use the API token, not the password) |
| 404 | wrong job name (it is case-sensitive) |

### 8.3 DevOps Jenkins: store the QA token
On the DevOps Jenkins (EC2-A, port 8080):
1. **Manage Jenkins** → **Credentials** → **System** → **Global credentials** → **Add Credentials**.
2. Kind **Username with password**; Username `demo-trigger`; Password = the API token; ID **`demo-qa-api`** (exactly) → **Create**.

### 8.4 Deploy and trigger QA automatically
1. `demo-deploy` → **Build with Parameters**:

   | Parameter | Value |
   |-----------|-------|
   | `BRANCH` | `main` |
   | `HEALTH_URL` | `http://localhost:8085/health` (back to normal!) |
   | `QA_JENKINS_URL` | `http://<EC2-B IP>:8080` |
   | `QA_JOB_NAME` | `demo-qa-job` |
   | `APP_URL` | `http://<EC2-A IP>:8085` |
   | `TRIGGER_QA` | **ticked** |

2. **Build**. After the deploy the last stage prints:

   ```
   Triggering QA job: http://<EC2-B IP>:8080/job/demo-qa-job/buildWithParameters (APP_URL=...)
   QA Jenkins responded with HTTP 201
   QA trigger request submitted.
   ```
3. Open the **QA Jenkins**: a new `demo-qa-job` build is running or finished, 6 tests passed.

### 8.5 Make it automatic
Edit `demo-app/Jenkinsfile`: change `TRIGGER_QA` to `defaultValue: true`, plus set the real `QA_JENKINS_URL` and `APP_URL` defaults. Commit, push, **Build with Parameters**: now every deployment starts QA without ticking anything.

Full flow achieved: **push → Jenkins deploys → health check → QA job on the other Jenkins → test report.**

### 8.6 (Bonus) Start the deploy on every push
GitHub repo `demo-app` → **Settings → Webhooks → Add webhook** → Payload URL `http://<EC2-A IP>:8080/github-webhook/`, content type `application/json`, push events. In the job → **Configure** → **Build Triggers** → tick **GitHub hook trigger for GITScm polling**. (EC2-A's security group must allow 8080 from GitHub's webhook IPs, or use *Poll SCM* with `H/5 * * * *` instead.)

---

## 9. (Optional) QA result e-mail
1. Gmail: Google Account → **Security** → enable **2-Step Verification** → **App passwords** → create `jenkins` → copy the 16 characters.
2. QA Jenkins: **Manage Jenkins → Plugins → Available** → install **Email Extension** → restart.
3. **Manage Jenkins → System → Extended E-mail Notification**: SMTP server `smtp.gmail.com`, port `465`, **Advanced** → add credentials (your Gmail + app password), tick **Use SSL**. Use **Test configuration by sending test e-mail** → **Save**.
4. `demo-qa-job` → **Build with Parameters** → tick `SEND_EMAIL`, set `EMAIL_TO` → **Build** → e-mail arrives.

(Bikerz uses this same e-mail setup.)

---

## 10. Quick reference: where things are

| What | Where |
|------|-------|
| DevOps Jenkins | `http://<EC2-A IP>:8080` |
| QA Jenkins | `http://<EC2-B IP>:8080` |
| Demo app | `http://<EC2-A IP>:8085` |
| Deployed code on EC2-A | `/home/ubuntu/demo-app` (previous version in `demo-app_old`) |
| Jenkins logs | `sudo journalctl -u jenkins -n 100` |
| App logs | `cd /home/ubuntu/demo-app && docker compose logs --tail=50` |
| Restart Jenkins | `sudo systemctl restart jenkins` |

---

## 11. Troubleshooting

| Problem | Fix |
|---------|-----|
| Cannot open `http://<IP>:8080` | security group has 8080 from **your** IP? Your home IP may have changed: edit the rule. `sudo systemctl status jenkins` |
| Cannot open `http://<EC2-A IP>:8085` | 8085 rule in `demo-a-sg`; `docker compose ps` on EC2-A |
| `Set REPO in the Jenkinsfile...` | you did not replace `<YOUR-GITHUB-USER>` (step 1.4); fix, commit, push |
| `No such DSL method 'sshagent'` | SSH Agent plugin missing (step 3.3) |
| `Host key verification failed` | the script's step 6 did not run: `ssh-keyscan -H 127.0.0.1 \| sudo -u jenkins tee -a /var/lib/jenkins/.ssh/known_hosts` |
| `Permission denied (publickey)` in deploy | credential `demo-server-ssh` has the wrong key or username (must be `ubuntu` + the printed private key) |
| `permission denied ... docker.sock` | log out/in on EC2-A so the docker group applies; `groups` must show `docker` |
| `docker: 'compose' is not a command` | `sudo apt-get install -y docker-compose-plugin` |
| `port is already allocated` | something else uses 8085: `sudo ss -ltnp \| grep 8085` |
| Health check fails | `docker compose logs` on EC2-A; check `HEALTH_URL` |
| `Could not resolve host: github.com` / clone fails | EC2 has no internet: check the instance has a public/Elastic IP and the VPC route |
| QA trigger timeout / 401 / 403 / 404 | see the table in step 8.2 |
| `QA_JENKINS_URL is not set to the real...` | the parameter still contains `QA-EC2-IP` |
| QA job: `APP_URL still contains the placeholder` | run with `APP_URL=http://<EC2-A IP>:8085` |
| QA job: `Check application is reachable` fails | `demo-a-sg` needs 8085 from `<EC2-B IP>/32` (step 2.5) |
| Parameters not shown in Build with Parameters | run **Build Now** once after changing the Jenkinsfile |
| Jenkins very slow / out of memory | use `t3.medium`; check `free -h` (swap is enabled by the scripts) |

---

## 12. Clean up (important: stops the AWS cost)

1. EC2 → **Instances** → select both → **Instance state → Terminate instance**.
2. EC2 → **Elastic IPs** → select each → **Actions → Release Elastic IP addresses**. (Unused Elastic IPs are charged.)
3. EC2 → **Security Groups** → delete `demo-a-sg` and `demo-b-sg` (optional).
4. Optional: delete the key pair.

Prefer to keep the practice servers? Use **Stop instance** instead (not Terminate); you pay only for the disk, but release or keep Elastic IPs in mind.

---

## 13. How this maps to Bikerz

| Same in Bikerz | Different in Bikerz |
|----------------|---------------------|
| Two Jenkins, two projects, two repos | App server is a **separate EC2** (`3.133.28.120`) from the DevOps Jenkins. Jenkins SSHes to it over the network (credential `routeiq-backend`), not to 127.0.0.1 |
| Pipeline from SCM, parameters, first-run registers them | Repos are **private** and cloned over **SSH** (deploy key + agent forwarding) |
| Docker Compose build, swap folders, health check, automatic rollback | Two containers (nginx web + Node API), port **8090** |
| `qa-jenkins-api` style credential and `buildWithParameters` trigger | QA credential ID is `qa-jenkins-api`, user `devops-trigger` |
| QA job reads `APP_URL`, runs tests, publishes a report | QA tests are **Selenium + TestNG + Allure** in headless Chrome (needs JDK, Maven, Chrome, t3.medium) |
| JUnit/e-mail on the QA Jenkins | Plus Allure HTML report, ZIP archive, e-mail with attachment |
| SG rules: 8080 between Jenkins servers, app port from QA EC2 | Three machines to open between (DevOps Jenkins, App EC2, QA EC2) |

When the demo works for you, continue with `SETUP-GUIDE.md` and the Bikerz READMEs.
