// Bikerz API - zero dependencies (Node 18+).
// Endpoints:
//   GET /health                      -> { status: "ok" }
//   GET /api/brands                  -> brands with model counts
//   GET /api/bikes?brand=&q=&category=&sort=price-asc|price-desc|name|cc
//   GET /api/bikes/:id               -> one model with versions + specs
// Optional: set STATIC_DIR to also serve the website (handy for local dev).

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = parseInt(process.env.PORT || '3000', 10);
const STATIC_DIR = process.env.STATIC_DIR ? path.resolve(process.env.STATIC_DIR) : null;
const DATA_FILE = path.join(__dirname, 'data', 'bikes.json');

function loadData() {
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}
let data = loadData();

const minPrice = (b) => Math.min(...b.versions.map((v) => v.price));
const maxPrice = (b) => Math.max(...b.versions.map((v) => v.price));
const summary = (b) => ({
  id: b.id, brand: b.brand, name: b.name, category: b.category, tagline: b.tagline,
  cc: b.cc, image: b.image, minPrice: minPrice(b), maxPrice: maxPrice(b),
  versionCount: b.versions.length,
});

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8', '.json': 'application/json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
};

function send(res, code, body, type = 'application/json; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-cache' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}

function serveStatic(req, res, pathname) {
  if (!STATIC_DIR) return false;
  let rel = decodeURIComponent(pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(STATIC_DIR, rel));
  if (!file.startsWith(STATIC_DIR)) { send(res, 403, { error: 'forbidden' }); return true; }
  fs.readFile(file, (err, buf) => {
    if (err) return send(res, 404, { error: 'not found' });
    send(res, 200, buf, MIME[path.extname(file)] || 'application/octet-stream');
  });
  return true;
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;

  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { error: 'method not allowed' });

  if (p === '/health' || p === '/api/health') {
    return send(res, 200, { status: 'ok', service: 'bikerz-api', models: data.bikes.length, time: new Date().toISOString() });
  }

  if (p === '/api/brands') {
    return send(res, 200, data.brands.map((br) => ({
      ...br, models: data.bikes.filter((b) => b.brand === br.id).length,
    })));
  }

  if (p === '/api/meta') {
    return send(res, 200, {
      ...data.meta,
      categories: [...new Set(data.bikes.map((b) => b.category))].sort(),
    });
  }

  if (p === '/api/bikes') {
    const brand = url.searchParams.get('brand');
    const category = url.searchParams.get('category');
    const q = (url.searchParams.get('q') || '').trim().toLowerCase();
    const sort = url.searchParams.get('sort') || 'name';
    let list = data.bikes.slice();
    if (brand) list = list.filter((b) => b.brand === brand);
    if (category) list = list.filter((b) => b.category.toLowerCase() === category.toLowerCase());
    if (q) {
      list = list.filter((b) =>
        (b.name + ' ' + b.brand + ' ' + b.category + ' ' + b.versions.map((v) => v.name).join(' '))
          .toLowerCase().includes(q));
    }
    const sorters = {
      'price-asc': (a, b) => minPrice(a) - minPrice(b),
      'price-desc': (a, b) => minPrice(b) - minPrice(a),
      cc: (a, b) => b.cc - a.cc,
      name: (a, b) => a.name.localeCompare(b.name),
    };
    list.sort(sorters[sort] || sorters.name);
    return send(res, 200, list.map(summary));
  }

  const m = p.match(/^\/api\/bikes\/([\w-]+)$/);
  if (m) {
    const bike = data.bikes.find((b) => b.id === m[1]);
    if (!bike) return send(res, 404, { error: 'bike not found' });
    const brand = data.brands.find((b) => b.id === bike.brand);
    return send(res, 200, { ...bike, brandName: brand ? brand.name : bike.brand, minPrice: minPrice(bike), maxPrice: maxPrice(bike) });
  }

  if (p.startsWith('/api/')) return send(res, 404, { error: 'unknown endpoint' });
  if (!serveStatic(req, res, p)) send(res, 404, { error: 'not found' });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Bikerz API listening on :${PORT} (${data.bikes.length} models)${STATIC_DIR ? ', serving ' + STATIC_DIR : ''}`);
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
