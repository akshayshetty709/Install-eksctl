#!/usr/bin/env bash
# One-time setup for the Ubuntu deploy server (run as the ubuntu user).
#   bash setup-server.sh
set -euo pipefail

echo "== Installing Docker, Compose plugin, git, curl =="
sudo apt-get update -y
sudo apt-get install -y ca-certificates curl git gnupg
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sudo sh
fi
sudo apt-get install -y docker-compose-plugin || true

echo "== Allow the ubuntu user to run docker without sudo =="
sudo usermod -aG docker "$USER"

echo "== Trust GitHub host key (needed for git clone over SSH) =="
mkdir -p ~/.ssh && chmod 700 ~/.ssh
ssh-keyscan -H github.com >> ~/.ssh/known_hosts 2>/dev/null
sort -u ~/.ssh/known_hosts -o ~/.ssh/known_hosts

echo "== Versions =="
docker --version
docker compose version
git --version
echo
echo "Done. LOG OUT AND BACK IN (or run: newgrp docker) so the docker group applies."
