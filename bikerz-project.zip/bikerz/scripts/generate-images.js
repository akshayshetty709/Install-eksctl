#!/usr/bin/env node
// Generates a classic, vintage-poster style SVG illustration for every bike in api/data/bikes.json
// into web/images/bikes/<id>.svg.  Run:  node scripts/generate-images.js
//
// These are illustrations (placeholders), not photos. To use real photos, drop <id>.jpg / .webp /
// .png files into web/images/bikes/ and change the "image" field of that bike in bikes.json.

const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const data = JSON.parse(fs.readFileSync(path.join(root, 'api/data/bikes.json'), 'utf8'));
const outDir = path.join(root, 'web/images/bikes');
fs.mkdirSync(outDir, { recursive: true });

const INK = '#2b1d14';
const CHROME = '#bfb6a3';

function wheel(cx, cy, r) {
  let spokes = '';
  for (let i = 0; i < 16; i++) {
    const a = (i * Math.PI * 2) / 16;
    spokes += `<line x1="${cx}" y1="${cy}" x2="${(cx + Math.cos(a) * (r - 8)).toFixed(1)}" y2="${(cy + Math.sin(a) * (r - 8)).toFixed(1)}" stroke="${INK}" stroke-width="1.2" opacity=".55"/>`;
  }
  return `<g>
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${INK}" stroke-width="13"/>
    <circle cx="${cx}" cy="${cy}" r="${r - 8}" fill="none" stroke="${CHROME}" stroke-width="3"/>
    ${spokes}
    <circle cx="${cx}" cy="${cy}" r="11" fill="${CHROME}" stroke="${INK}" stroke-width="3"/>
    <circle cx="${cx}" cy="${cy}" r="${r - 22}" fill="none" stroke="${INK}" stroke-width="5" opacity=".75"/>
  </g>`;
}

function engine(x, y, w, h) {
  let fins = '';
  for (let i = 1; i <= 5; i++) fins += `<line x1="${x + 8}" y1="${y + 6 + i * 7}" x2="${x + w - 8}" y2="${y + 6 + i * 7}" stroke="${INK}" stroke-width="2" opacity=".6"/>`;
  return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="12" fill="#6e6454" stroke="${INK}" stroke-width="4"/>
    ${fins}<circle cx="${x + w / 2}" cy="${y + h - 16}" r="13" fill="${CHROME}" stroke="${INK}" stroke-width="3"/>`;
}

function classic(accent) {
  return `
  ${wheel(210, 310, 70)}${wheel(590, 310, 70)}
  <path d="M130 292 C140 222 280 222 292 290" fill="none" stroke="${accent}" stroke-width="9" stroke-linecap="round"/>
  <path d="M510 288 C520 238 640 238 660 292" fill="none" stroke="${accent}" stroke-width="8" stroke-linecap="round"/>
  <path d="M210 310 L330 300 L420 300 L520 175" fill="none" stroke="${INK}" stroke-width="9" stroke-linejoin="round" stroke-linecap="round"/>
  <path d="M590 310 L520 175" stroke="${INK}" stroke-width="9" stroke-linecap="round"/>
  <path d="M518 172 L500 128 L470 120" fill="none" stroke="${INK}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M345 360 C300 372 230 372 150 366" fill="none" stroke="${CHROME}" stroke-width="16" stroke-linecap="round"/>
  <path d="M345 360 C300 372 230 372 150 366" fill="none" stroke="${INK}" stroke-width="2" opacity=".5"/>
  ${engine(310, 285, 120, 85)}
  <path d="M338 207 C358 158 462 158 502 190 L492 236 C440 252 380 252 338 236 Z" fill="${accent}" stroke="${INK}" stroke-width="5"/>
  <path d="M360 190 C400 172 450 172 480 192" fill="none" stroke="#fff" stroke-width="3" opacity=".35"/>
  <path d="M226 226 C262 212 322 212 346 224 L342 246 C300 252 250 252 224 244 Z" fill="#3a2a20" stroke="${INK}" stroke-width="4"/>
  <circle cx="538" cy="190" r="22" fill="#f1d98c" stroke="${INK}" stroke-width="5"/>
  <circle cx="538" cy="190" r="10" fill="#fff6d1"/>
  <line x1="238" y1="248" x2="262" y2="300" stroke="${INK}" stroke-width="7"/>
  <line x1="470" y1="120" x2="455" y2="116" stroke="${INK}" stroke-width="10" stroke-linecap="round"/>`;
}

function naked(accent) {
  return `
  ${wheel(205, 310, 68)}${wheel(595, 310, 68)}
  <path d="M595 310 L525 168" stroke="${INK}" stroke-width="10" stroke-linecap="round"/>
  <path d="M205 310 L335 290 L470 290 L525 168" fill="none" stroke="${INK}" stroke-width="9" stroke-linejoin="round" stroke-linecap="round"/>
  <path d="M345 208 L520 172 L506 226 L400 250 L345 242 Z" fill="${accent}" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/>
  <path d="M345 215 L300 190 L170 188 L150 210 L300 238 L345 242" fill="${accent}" stroke="${INK}" stroke-width="5" stroke-linejoin="round" opacity=".92"/>
  <path d="M300 240 L190 232 L186 214 L300 224 Z" fill="#3a2a20" stroke="${INK}" stroke-width="4"/>
  ${engine(330, 262, 115, 95)}
  <path d="M440 345 L330 372 L190 362" fill="none" stroke="${CHROME}" stroke-width="15" stroke-linecap="round"/>
  <path d="M525 168 L510 112 L474 104" fill="none" stroke="${INK}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M520 168 L572 190 L560 224 L520 214 Z" fill="#f1d98c" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/>
  <path d="M590 262 C600 232 650 232 660 260" fill="none" stroke="${accent}" stroke-width="7" stroke-linecap="round"/>`;
}

function sport(accent) {
  return `
  ${wheel(205, 310, 66)}${wheel(598, 310, 66)}
  <path d="M598 310 L520 190" stroke="${INK}" stroke-width="10" stroke-linecap="round"/>
  <path d="M205 310 L330 280 L470 285" fill="none" stroke="${INK}" stroke-width="9" stroke-linejoin="round" stroke-linecap="round"/>
  ${engine(335, 268, 115, 92)}
  <path d="M440 350 L320 374 L180 364" fill="none" stroke="${CHROME}" stroke-width="15" stroke-linecap="round"/>
  <path d="M150 232 L170 200 L330 206 L420 196 L520 168 L585 224 L560 292 L470 292 L420 262 L330 262 L180 252 Z" fill="${accent}" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/>
  <path d="M455 205 L520 180 L560 224 L520 240 Z" fill="#cfe3ea" stroke="${INK}" stroke-width="4" stroke-linejoin="round" opacity=".9"/>
  <path d="M215 235 L330 238 L360 218 L330 210 L190 206 Z" fill="#3a2a20" stroke="${INK}" stroke-width="4"/>
  <path d="M470 172 L458 130 L416 124" fill="none" stroke="${INK}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="572" cy="236" r="12" fill="#f1d98c" stroke="${INK}" stroke-width="4"/>
  <path d="M588 255 C610 232 650 236 664 262" fill="none" stroke="${INK}" stroke-width="6" stroke-linecap="round"/>`;
}

function scooter(accent) {
  return `
  ${wheel(220, 332, 52)}${wheel(590, 332, 48)}
  <path d="M150 318 C130 240 190 190 280 190 L430 210 L470 262 C440 296 300 298 262 330 L180 330 Z" fill="${accent}" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/>
  <path d="M430 275 L600 290 L570 250 L520 190 L470 262 Z" fill="${accent}" stroke="${INK}" stroke-width="5" stroke-linejoin="round" opacity=".95"/>
  <path d="M470 262 L440 330 L330 340 L300 300 Z" fill="#6e6454" stroke="${INK}" stroke-width="4" stroke-linejoin="round" opacity=".85"/>
  <path d="M240 186 C280 160 380 160 430 192 L430 214 L250 208 Z" fill="#3a2a20" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/>
  <path d="M590 332 L548 196" stroke="${INK}" stroke-width="9" stroke-linecap="round"/>
  <path d="M548 196 L534 120 L490 108" fill="none" stroke="${INK}" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M520 124 L568 130 L560 168 L526 160 Z" fill="#f1d98c" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/>
  <path d="M150 340 L260 344" stroke="${CHROME}" stroke-width="14" stroke-linecap="round"/>
  <path d="M556 276 C568 246 618 246 636 288" fill="none" stroke="${accent}" stroke-width="7" stroke-linecap="round"/>`;
}

const brandById = Object.fromEntries(data.brands.map((b) => [b.id, b]));

function render(bike) {
  const brand = brandById[bike.brand];
  const accent = brand.accent;
  const kind = bike.category === 'Scooter' ? scooter
    : bike.category === 'Sport' ? sport
      : ['Naked', 'Street'].includes(bike.category) ? naked : classic;
  const name = bike.name.replace(/&/g, '&amp;');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500" role="img" aria-label="${name}">
  <defs>
    <radialGradient id="bg" cx="50%" cy="45%" r="75%">
      <stop offset="0" stop-color="#f7efd9"/><stop offset=".7" stop-color="#e9dbb8"/><stop offset="1" stop-color="#cdb98b"/>
    </radialGradient>
    <filter id="grain"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="4"/><feColorMatrix values="0 0 0 0 .3  0 0 0 0 .2  0 0 0 0 .1  0 0 0 .08 0"/></filter>
  </defs>
  <rect width="800" height="500" fill="url(#bg)"/>
  <rect width="800" height="500" filter="url(#grain)"/>
  <rect x="14" y="14" width="772" height="472" fill="none" stroke="${INK}" stroke-width="3"/>
  <rect x="24" y="24" width="752" height="452" fill="none" stroke="#b08a3e" stroke-width="1.5"/>
  <text x="400" y="74" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-size="22" letter-spacing="7" fill="${accent}">${brand.name.toUpperCase()}</text>
  <line x1="300" y1="88" x2="500" y2="88" stroke="#b08a3e" stroke-width="1.5"/>
  <ellipse cx="400" cy="392" rx="330" ry="14" fill="${INK}" opacity=".18"/>
  <g>${kind(accent)}</g>
  <text x="400" y="452" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-style="italic" font-size="30" fill="${INK}">${name}</text>
</svg>`;
}

let n = 0;
for (const bike of data.bikes) {
  fs.writeFileSync(path.join(outDir, `${bike.id}.svg`), render(bike));
  n++;
}
console.log(`Generated ${n} images in ${outDir}`);
