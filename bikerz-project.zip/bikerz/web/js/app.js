(function () {
  'use strict';

  var state = { brand: '', q: '', category: '', sort: 'name', brands: [] };
  var $ = function (id) { return document.getElementById(id); };

  // Indian digit grouping: 181000 -> ₹1,81,000
  function inr(n) {
    return '₹' + Number(n).toLocaleString('en-IN');
  }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function getJSON(url) {
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error(url + ' -> HTTP ' + r.status);
      return r.json();
    });
  }
  function brandName(id) {
    var b = state.brands.filter(function (x) { return x.id === id; })[0];
    return b ? b.name : id;
  }

  // ---------- Brand navigation ----------
  function renderBrands() {
    var total = state.brands.reduce(function (a, b) { return a + b.models; }, 0);
    var html = '<button class="brand-btn' + (state.brand === '' ? ' active' : '') + '" data-brand="">All <small>(' + total + ')</small></button>';
    state.brands.forEach(function (b) {
      html += '<button class="brand-btn' + (state.brand === b.id ? ' active' : '') + '" data-brand="' + esc(b.id) + '">' +
        esc(b.name) + ' <small>(' + b.models + ')</small></button>';
    });
    $('brandNav').innerHTML = html;
  }

  function renderIntro() {
    var el = $('brandIntro');
    var b = state.brands.filter(function (x) { return x.id === state.brand; })[0];
    if (!b) { el.hidden = true; return; }
    el.hidden = false;
    el.innerHTML = '<h2>' + esc(b.name) + '</h2><div class="meta">' + esc(b.country) + ' &middot; since ' + b.founded + '</div><p>' + esc(b.blurb) + '</p>';
  }

  // ---------- Model list ----------
  function loadBikes() {
    var p = new URLSearchParams();
    if (state.brand) p.set('brand', state.brand);
    if (state.q) p.set('q', state.q);
    if (state.category) p.set('category', state.category);
    p.set('sort', state.sort);
    return getJSON('/api/bikes?' + p.toString()).then(function (list) {
      $('count').textContent = list.length + (list.length === 1 ? ' model' : ' models') + ' found';
      $('empty').hidden = list.length > 0;
      $('grid').innerHTML = list.map(function (b) {
        var price = b.minPrice === b.maxPrice
          ? '<b>' + inr(b.minPrice) + '</b>'
          : '<b>' + inr(b.minPrice) + '</b><small>to ' + inr(b.maxPrice) + '</small>';
        return '<button class="card" data-id="' + esc(b.id) + '" aria-label="' + esc(b.name) + ' details">' +
          '<div class="photo"><img loading="lazy" src="' + esc(b.image) + '" alt="' + esc(b.name) + '"></div>' +
          '<div class="body">' +
          '<div class="brandline">' + esc(brandName(b.brand)) + '</div>' +
          '<h3>' + esc(b.name) + '</h3>' +
          '<p class="tag">' + esc(b.tagline) + '</p>' +
          '<div class="chips"><span class="chip">' + esc(b.category) + '</span><span class="chip">' + esc(b.cc) + ' cc</span>' +
          '<span class="chip">' + b.versionCount + (b.versionCount === 1 ? ' version' : ' versions') + '</span></div>' +
          '<div class="price"><small>Ex-showroom from</small>' + price + '</div>' +
          '</div></button>';
      }).join('');
    }).catch(function (err) {
      $('count').textContent = 'Could not load the catalogue. Please try again shortly.';
      console.error(err);
    });
  }

  // ---------- Detail dialog ----------
  var lastFocus = null;
  function openModal(id) {
    lastFocus = document.activeElement;
    getJSON('/api/bikes/' + encodeURIComponent(id)).then(function (b) {
      var versions = b.versions.map(function (v) {
        return '<tr><td><strong>' + esc(v.name) + '</strong></td>' +
          '<td>' + esc(v.highlights) + '</td>' +
          '<td>' + v.colours.map(function (c) { return '<span class="colour">' + esc(c) + '</span>'; }).join('') + '</td>' +
          '<td class="price-cell">' + inr(v.price) + '</td></tr>';
      }).join('');
      var specs = Object.keys(b.specs).map(function (k) {
        return '<tr><th>' + esc(k) + '</th><td>' + esc(b.specs[k]) + '</td></tr>';
      }).join('');
      var range = b.minPrice === b.maxPrice ? inr(b.minPrice) : inr(b.minPrice) + ' &ndash; ' + inr(b.maxPrice);
      $('modalBody').innerHTML =
        '<div class="detail-top">' +
        '<img src="' + esc(b.image) + '" alt="' + esc(b.name) + '">' +
        '<div><div class="brandline">' + esc(b.brandName) + ' &middot; ' + esc(b.category) + '</div>' +
        '<h2 id="mTitle">' + esc(b.name) + '</h2>' +
        '<p class="tag">' + esc(b.tagline) + '</p>' +
        '<p class="bigprice"><small>Ex-showroom price range</small>' + range + '</p></div></div>' +
        '<h3 class="section-title">Versions &amp; Prices</h3>' +
        '<div class="versions-wrap"><table><thead><tr><th>Version</th><th>Highlights</th><th>Colours</th><th>Price</th></tr></thead><tbody>' + versions + '</tbody></table></div>' +
        '<h3 class="section-title">Specifications</h3>' +
        '<table class="specs"><tbody>' + specs + '</tbody></table>' +
        '<p class="disclaimer">Prices are approximate and indicative. Please confirm the on-road price, colours and features with your authorised dealer.</p>';
      $('modal').hidden = false;
      document.body.style.overflow = 'hidden';
      $('closeModal').focus();
    }).catch(function (e) { console.error(e); });
  }
  function closeModal() {
    $('modal').hidden = true;
    document.body.style.overflow = '';
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  // ---------- Events ----------
  function debounce(fn, ms) {
    var t; return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); };
  }
  $('brandNav').addEventListener('click', function (e) {
    var btn = e.target.closest('.brand-btn'); if (!btn) return;
    state.brand = btn.getAttribute('data-brand');
    renderBrands(); renderIntro(); loadBikes();
  });
  $('grid').addEventListener('click', function (e) {
    var card = e.target.closest('.card'); if (card) openModal(card.getAttribute('data-id'));
  });
  $('search').addEventListener('input', debounce(function (e) { state.q = e.target.value; loadBikes(); }, 200));
  $('category').addEventListener('change', function (e) { state.category = e.target.value; loadBikes(); });
  $('sort').addEventListener('change', function (e) { state.sort = e.target.value; loadBikes(); });
  $('closeModal').addEventListener('click', closeModal);
  $('modal').addEventListener('click', function (e) { if (e.target === $('modal')) closeModal(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('modal').hidden) closeModal(); });

  // ---------- Init ----------
  $('year').textContent = new Date().getFullYear();
  Promise.all([getJSON('/api/brands'), getJSON('/api/meta')]).then(function (res) {
    state.brands = res[0];
    $('category').innerHTML = '<option value="">All types</option>' + res[1].categories.map(function (c) {
      return '<option>' + esc(c) + '</option>';
    }).join('');
    renderBrands();
    return loadBikes();
  }).catch(function (e) {
    $('count').textContent = 'Could not reach the Bikerz API.';
    console.error(e);
  });
})();
