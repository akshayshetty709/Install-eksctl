# Bikerz: Complete Setup Checklist (2 Jenkins + 2 EC2)

Two projects, two Jenkins servers, two EC2 environments:

| | DevOps side | QA side |
|---|---|---|
| Project folder | `bikerz/` | `bikerz-qa/` |
| GitHub repo | `bikerz` | `bikerz-qa` |
| Jenkins | existing **DevOps Jenkins** | **new QA Jenkins** (on the QA EC2) |
| EC2 | **App EC2** `3.133.28.120` (Docker, runs the site) | **QA EC2** (new; Jenkins + JDK17 + Maven + Chrome) |
| Job | `bikerz-deploy` | `Sample-QA-Automation-Job` |
| Detailed steps | `bikerz/README.md` | `bikerz-qa/README.md` |

```
git push ─► DevOps Jenkins ─ssh─► App EC2 :8090 (Bikerz)
                 │                      ▲
                 │ POST buildWithParameters (user + API token)
                 ▼                      │ tests over HTTP
            QA Jenkins on QA EC2 ───────┘
                 └► Allure report + HTML + ZIP + e-mail
```

## Network rules (security groups)

| On | Inbound rule | From |
|----|--------------|------|
| App EC2 | TCP 22 | DevOps Jenkins |
| App EC2 | TCP **8090** | QA EC2 IP (and users / your IP) |
| QA EC2 | TCP 22 | your IP |
| QA EC2 | TCP **8080** | **DevOps Jenkins public IP** + your IP |

Give the QA EC2 (and the DevOps Jenkins, if possible) an **Elastic IP** so addresses never change.

## Credentials (who stores what)

| Stored on | Credential ID | Holds | Used by |
|-----------|---------------|-------|---------|
| DevOps Jenkins | `routeiq-backend` | SSH key for the App EC2 (user `ubuntu`) | deploy stages |
| DevOps Jenkins | `qa-jenkins-api` | QA service account `devops-trigger` + API token | QA trigger stage |
| QA Jenkins | `github-bikerz-qa` | deploy key for the `bikerz-qa` repo | QA job checkout |

## Order of work (tick as you go)

**Part A – Bikerz on the App EC2 (`bikerz/README.md`)**
- [ ] A1. Unzip; run Bikerz locally (step 2)
- [ ] A2. Create GitHub repo `bikerz`, push, set `REPO` in the Jenkinsfile (step 4)
- [ ] A3. Give the Jenkins SSH key read access to the repo (step 5)
- [ ] A4. Set up the App EC2: Docker, port 8090 open (step 6)
- [ ] A5. Prepare DevOps Jenkins and create job `bikerz-deploy` (step 7)
- [ ] A6. Run the deploy; open `http://3.133.28.120:8090` (steps 8-9)

**Part B – QA project (`bikerz-qa/README.md`)**
- [ ] B1. Run the tests on your laptop against the live site (step 2) and fix any failure
- [ ] B2. Create GitHub repo `bikerz-qa` and push (step 3)

**Part C – QA EC2 + QA Jenkins (`bikerz-qa/README.md`)**
- [ ] C1. Launch QA EC2 (t3.medium, Ubuntu), security group, Elastic IP (steps 4.1-4.2)
- [ ] C2. Open app EC2 port 8090 to the QA EC2 (step 4.3)
- [ ] C3. Run `scripts/setup-qa-server.sh` on the QA EC2 (step 4.4)
- [ ] C4. First login to QA Jenkins and set the Jenkins URL (step 4.5)
- [ ] C5. GitHub deploy key + `github-bikerz-qa` credential (step 4.6)
- [ ] C6. Plugins, Allure tool, e-mail SMTP (step 5)
- [ ] C7. Create job `Sample-QA-Automation-Job` and run it by hand (steps 6-8)

**Part D – Connect the two Jenkins servers**
- [ ] D1. On QA Jenkins: create `devops-trigger` user, permissions, API token (step 9)
- [ ] D2. Test the trigger with `curl` from the DevOps Jenkins machine (step 9.4)
- [ ] D3. On DevOps Jenkins: add credential `qa-jenkins-api` (step 10.1)
- [ ] D4. Run `bikerz-deploy` with `TRIGGER_QA` ticked and `QA_JENKINS_URL` set (step 10)
- [ ] D5. Confirm a QA build starts, the Allure report opens and the e-mail arrives
- [ ] D6. Change the `TRIGGER_QA` default to `true` and push

## Known limits
- Prices/specs in `bikes.json` are indicative; verify before publishing.
- Images are generated illustrations, not photos.
- The Maven test build, Docker build and Jenkins runs were written but not executed during development; expect small adjustments on the first run.
- The trigger starts the QA job but does not wait for the result.
