# Bikerz QA Automation (separate QA Jenkins + separate QA EC2)

Selenium + TestNG + Allure test suite for the **Bikerz** site. It runs in its own Jenkins job, **`Sample-QA-Automation-Job`**, on a **separate QA Jenkins server (its own EC2)**. The DevOps Jenkins starts it after every successful deployment.

- 7 API tests, 9 catalogue/UI tests, 29 model-detail tests (one per model) = **about 45 test runs**
- Headless Chrome, application URL from the system property **`baseUrl`**
- After the run: **Allure report, HTML report, ZIP archive and e-mail notification**

## The two environments

```
 DevOps side                                            QA side
┌──────────────────────┐                             ┌───────────────────────────────┐
│ DevOps Jenkins       │  1. POST buildWithParameters│ QA EC2  (QA Jenkins :8080)    │
│  job: bikerz-deploy  │ ───────────────────────────►│  job: Sample-QA-Automation-Job│
│                      │  user + API token, APP_URL  │  JDK17 + Maven + Chrome       │
└─────────┬────────────┘                             └──────────────┬────────────────┘
          │ 0. deploy over SSH                                      │ 2. browser + API tests
          ▼                                                         ▼
┌──────────────────────┐   <──────────── HTTP :8090 ───────────────┘
│ App EC2 3.133.28.120 │
│  Docker: Bikerz      │      3. QA Jenkins → Allure report + HTML + ZIP + e-mail
└──────────────────────┘
```

| Machine | What it is | Ports that must be open (inbound) |
|---------|-----------|-----------------------------------|
| **App EC2** `3.133.28.120` | runs Bikerz in Docker (already set up with the Bikerz README) | `22` from DevOps Jenkins, `8090` from the **QA EC2** (and users) |
| **QA EC2** (new) | QA Jenkins + test tools | `22` from your IP, `8080` from **DevOps Jenkins IP** and your IP |
| **DevOps Jenkins** | existing | none new (it only calls out to the QA EC2) |

## 0. Project layout

```
bikerz-qa/
├── Jenkinsfile                          # pipeline of Sample-QA-Automation-Job
├── pom.xml                              # dependencies, Surefire + Allure agent
├── scripts/setup-qa-server.sh           # installs JDK, Maven, Chrome, Jenkins on the QA EC2
└── src/test
    ├── resources/testng.xml             # which test classes run
    ├── resources/allure.properties
    └── java/com/bikerz/qa
        ├── utils/Config.java            # baseUrl / headless from -D properties
        ├── utils/ApiClient.java         # HTTP helper for API tests
        ├── pages/HomePage.java          # page object: catalogue page
        ├── pages/DetailPage.java        # page object: model details dialog
        └── tests/
            ├── BaseTest.java            # starts Chrome, screenshot on failure
            ├── ApiTest.java             # /health, /api/brands, /api/bikes...
            ├── HomePageTest.java        # brands, search, filter, sorting
            └── DetailTest.java          # versions, prices, specs, image (all models)
```

> The element selectors used by the tests were checked against the running Bikerz site in a browser. The Maven build itself (library download and test run) could not be executed where these files were written, so **do the local run in step 2 first** and fix anything it reports before you build the QA server.

Some tests expect the sample data (9 brands, 27+ models, KTM = 3 models, Classic 350 = 4 versions, Scooter type = 2 models). If you change `bikes.json` in the Bikerz project, update those numbers in `ApiTest`, `HomePageTest` and `DetailTest`.

---

## 1. Prerequisites

| Where | What |
|-------|------|
| Your laptop | JDK 17+, Maven 3.8+, Google Chrome, Git (only for the local test run in step 2) |
| AWS account | permission to launch an EC2 instance and edit security groups |
| GitHub | an empty private repo `bikerz-qa` |
| App EC2 | Bikerz already deployed and reachable at `http://3.133.28.120:8090` |

Laptop install (Ubuntu):

```bash
sudo apt-get update
sudo apt-get install -y openjdk-17-jdk maven
wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo apt-get install -y ./google-chrome-stable_current_amd64.deb
```

---

## 2. Run the tests on your laptop first

1. Start Bikerz (either option):
   - `cd bikerz && docker compose up -d --build` → `http://localhost:8090`
   - or `cd bikerz/api && STATIC_DIR=../web node server.js` → `http://localhost:3000`
   - or simply test the deployed site: `http://3.133.28.120:8090`
2. Run the tests:

   ```bash
   cd bikerz-qa
   mvn clean test -DbaseUrl=http://localhost:8090 -Dheadless=true
   ```
   (use `-Dheadless=false` to watch the browser)
3. Expected end of output:

   ```
   Tests run: 45, Failures: 0, Errors: 0, Skipped: 0
   BUILD SUCCESS
   ```
4. View the report (needs the Allure CLI): `allure serve target/allure-results`
5. To run only one test class while debugging, temporarily edit `src/test/resources/testng.xml` and keep just that `<class>` (for example only `ApiTest`), then run the same `mvn` command. Put the file back afterwards.

If something fails here, fix it **before** continuing.

---

## 3. Put the QA project in GitHub

```bash
cd bikerz-qa
git init
git add .
git commit -m "Bikerz QA automation"
git branch -M main
git remote add origin git@github.com:<YOUR-GITHUB-ORG>/bikerz-qa.git
git push -u origin main
```

---

## 4. Create the QA EC2 server and QA Jenkins (one time)

### 4.1 Launch the EC2 instance
1. AWS Console → **EC2** → **Launch instance**.
2. Name: `bikerz-qa-jenkins`.
3. AMI: **Ubuntu Server 22.04 LTS** (or 24.04), 64-bit x86.
4. Instance type: **t3.medium** (2 vCPU, 4 GB). `t3.small` is too tight for Jenkins + Chrome.
5. Key pair: choose or create one (download the `.pem` and keep it safe).
6. Network: same region and VPC as the app EC2 is the simplest.
7. Storage: **30 GB** gp3.
8. Security group: create `bikerz-qa-sg` with these **inbound** rules:

   | Type | Port | Source | Why |
   |------|------|--------|-----|
   | SSH | 22 | **My IP** | you log in |
   | Custom TCP | 8080 | **My IP** | you open the QA Jenkins UI |
   | Custom TCP | 8080 | `<DevOps-Jenkins-public-IP>/32` | DevOps Jenkins triggers the job |

   (Find the DevOps Jenkins public IP with `curl ifconfig.me` on that machine. If it is in the same VPC you can use its private IP instead.)
9. Click **Launch instance**.

### 4.2 Give the QA EC2 a fixed IP
A stopped/started EC2 gets a new public IP, which would break the trigger. So:
1. EC2 → **Elastic IPs** → **Allocate Elastic IP address** → Allocate.
2. Select it → **Actions → Associate Elastic IP address** → choose `bikerz-qa-jenkins` → Associate.
3. Note this IP. Below it is written as `<QA-EC2-IP>`.

### 4.3 Let the QA EC2 reach the app EC2
1. EC2 → the **app** server's security group → **Edit inbound rules**.
2. Add: Custom TCP, port **8090**, source **`<QA-EC2-IP>/32`** (skip if 8090 is already open to `0.0.0.0/0`).

### 4.4 Install everything on the QA EC2
1. Log in from your laptop:

   ```bash
   chmod 400 ~/Downloads/your-qa-key.pem
   ssh -i ~/Downloads/your-qa-key.pem ubuntu@<QA-EC2-IP>
   ```
2. Copy `scripts/setup-qa-server.sh` to the server (for example `scp -i your-qa-key.pem scripts/setup-qa-server.sh ubuntu@<QA-EC2-IP>:~`) and run:

   ```bash
   bash setup-qa-server.sh
   ```
   It adds swap, installs JDK 17, Maven, Chrome and Jenkins, trusts GitHub's host key for the `jenkins` user, and prints the **initial admin password** at the end. Copy it.
3. Check the app is reachable from here:

   ```bash
   curl -fsS http://3.133.28.120:8090/health
   ```
   You must see `{"status":"ok",...}`. If it hangs, repeat step 4.3.

### 4.5 First login to the QA Jenkins
1. Browser: `http://<QA-EC2-IP>:8080`
2. Paste the initial admin password → **Install suggested plugins** → wait.
3. Create the first admin user (use a strong password) → **Save and Continue**.
4. **Jenkins URL**: `http://<QA-EC2-IP>:8080/` → **Save and Finish** → **Start using Jenkins**.

### 4.6 Let the QA Jenkins read the `bikerz-qa` GitHub repo
1. On the QA EC2 create a key for the `jenkins` user:

   ```bash
   sudo -u jenkins ssh-keygen -t ed25519 -f /var/lib/jenkins/.ssh/id_ed25519 -N "" -C "qa-jenkins"
   sudo cat /var/lib/jenkins/.ssh/id_ed25519.pub
   ```
2. GitHub → repo `bikerz-qa` → **Settings → Deploy keys → Add deploy key** → paste the public key → leave write access **unticked**.
3. QA Jenkins → **Manage Jenkins → Credentials → (global) → Add Credentials**:
   - Kind: **SSH Username with private key**
   - ID: `github-bikerz-qa`
   - Username: `git`
   - Private key → **Enter directly** → paste the output of `sudo cat /var/lib/jenkins/.ssh/id_ed25519`
   - **Create**

---

## 5. Prepare the QA Jenkins (one time)

### 5.1 Plugins (click by click)
1. **Manage Jenkins** → **Plugins** → **Available plugins**.
2. Search each name, tick it, repeat for all:

   | Plugin | Used for |
   |--------|----------|
   | **Allure** (Allure Jenkins Plugin) | Allure report |
   | **HTML Publisher** | `publishHTML` step |
   | **Pipeline Utility Steps** | `zip` step |
   | **Email Extension** | `emailext` step |

   (Git, Pipeline and Credentials are already there. If a plugin is not listed under *Available*, it is already installed.)
3. Click **Install**, tick **Restart Jenkins when installation is complete and no jobs are running**, wait about a minute and log in again.

### 5.2 Allure tool
1. **Manage Jenkins** → **Tools** → **Allure Commandline** → **Add Allure Commandline**.
2. Name: `allure` (exactly, lowercase).
3. Tick **Install automatically**, pick an **Allure 2.x** version.
4. **Save**.

### 5.3 E-mail / SMTP (Gmail example)
1. Gmail: Google Account → **Security** → turn on **2-Step Verification** → **App passwords** → create `jenkins` → copy the 16 characters.
2. QA Jenkins → **Manage Jenkins** → **System** → **Extended E-mail Notification**:
   - SMTP server `smtp.gmail.com`, port `465`
   - **Advanced** → **Add** credentials → *Username with password*: Gmail address + the app password → select it
   - Tick **Use SSL**
3. Scroll down → **Test configuration by sending test e-mail** → your address → you must receive it.
4. **Save**. (Company mail: use the SMTP host, port and credentials from IT.)

### 5.4 Check the tools as the Jenkins user
On the QA EC2:

```bash
sudo -u jenkins java -version
sudo -u jenkins mvn -v
sudo -u jenkins google-chrome --version
free -h
```
All three tools must print a version (Java 17+).

Optional: **Manage Jenkins → Nodes → Built-In Node → Configure** → *Number of executors* = `1` (tests run one at a time on this small server).

---

## 6. Create the QA job

1. Jenkins home → **New Item** → name **`Sample-QA-Automation-Job`** (exactly this) → **Pipeline** → OK.
2. **Pipeline** section → *Pipeline script from SCM* → SCM **Git**.
3. Repository URL: `git@github.com:<YOUR-GITHUB-ORG>/bikerz-qa.git`; Credentials: `github-bikerz-qa`; Branch: `*/main`.
4. Script Path: `Jenkinsfile` → **Save**.

---

## 7. First run of the QA job (manual)

1. **Build Now**. The first run only registers the parameters (`APP_URL`, `EMAIL_TO`).
2. **Build with Parameters**:
   - `APP_URL` = `http://3.133.28.120:8090`
   - `EMAIL_TO` = your e-mail
3. **Build**. Stages: Checkout → Check application is reachable → Run automation tests → (post) validate results, Allure report, HTML publish, ZIP + archive, e-mail.

---

## 8. Check the results

- Build page → **Allure Report** (graphs, failures with screenshots).
- Job page → **Allure HTML Report** (static copy).
- Build page → **Artifacts** → `allure-report.zip`.
- Your inbox: result e-mail with the ZIP attached.
- Console: `Tests run: ..., Failures: 0`.

---

## 9. Allow the DevOps Jenkins to trigger this job

### 9.1 Create the service account (on the QA Jenkins)
1. **Manage Jenkins** → **Users** → **Create User** → username `devops-trigger`, a strong password, full name `DevOps Trigger` → **Create**.

### 9.2 Give it permission
Default Jenkins security ("Logged-in users can do anything") already lets it build. For tighter security:
1. **Manage Jenkins** → **Security** → Authorization → **Matrix-based security** (add yourself as admin first!).
2. For `devops-trigger` tick only **Overall/Read**, **Job/Read**, **Job/Build** → **Save**.

### 9.3 Create its API token
1. Log in to the QA Jenkins **as `devops-trigger`**.
2. User name (top right) → **Security** → **API Token** → **Add new Token** → name `devops-trigger` → **Generate**.
3. **Copy the token now** (it is shown only once). Share it with the DevOps Jenkins only through a secure channel; never in chat, e-mail, screenshots or Git.

### 9.4 Test the trigger from the DevOps Jenkins machine
Run this on the **DevOps Jenkins server** (replace the values):

```bash
curl -i -X POST -u "devops-trigger:<API_TOKEN>" \
  --data-urlencode "APP_URL=http://3.133.28.120:8090" \
  "http://<QA-EC2-IP>:8080/job/Sample-QA-Automation-Job/buildWithParameters"
```

`HTTP/1.1 201 Created` = works, and a new build appears on the QA Jenkins. If it fails, see the troubleshooting table.

---

## 10. Connect it to the DevOps (Bikerz) pipeline

1. On the **DevOps Jenkins** → **Manage Jenkins** → **Credentials** → (global) → **Add Credentials**:
   - Kind: **Username with password**
   - Username: `devops-trigger`, Password: the API token from step 9.3
   - ID: **`qa-jenkins-api`** (exactly)
2. Open the Bikerz deploy job → **Build with Parameters**:

   | Parameter | Value |
   |-----------|-------|
   | `QA_JENKINS_URL` | `http://<QA-EC2-IP>:8080` |
   | `QA_JOB_NAME` | `Sample-QA-Automation-Job` |
   | `APP_URL` | `http://3.133.28.120:8090` |
   | `TRIGGER_QA` | ticked |

3. After the deploy succeeds, expect this in the stage log:

   ```
   Triggering QA job: http://<QA-EC2-IP>:8080/job/Sample-QA-Automation-Job/buildWithParameters (APP_URL=...)
   QA Jenkins responded with HTTP 201
   QA trigger request submitted.
   ```
4. Check a new build appears on the **QA Jenkins**, and that the Allure report and e-mail arrive.
5. When it works every time, change the `TRIGGER_QA` default to `true` in the Bikerz Jenkinsfile and push.

Full flow: **push code → DevOps Jenkins deploys to the app EC2 → health check OK → DevOps Jenkins calls QA Jenkins → QA EC2 runs tests against the app → Allure report + e-mail.**

The trigger only **starts** the QA job; it does not wait. QA results come from the QA Jenkins report and e-mail, and a failing QA run does not roll back the deployment.

---

## 11. Troubleshooting

| Problem | Fix |
|---------|-----|
| Cannot open `http://<QA-EC2-IP>:8080` | QA security group: port 8080 from your IP; `sudo systemctl status jenkins` on the QA EC2 |
| Trigger: connection timeout | QA security group needs 8080 from the **DevOps Jenkins IP**; check the IP with `curl ifconfig.me` on that machine; DevOps Jenkins public IP may have changed (use an Elastic IP) |
| Trigger: `QA_JENKINS_URL is not set to the real...` | the parameter still holds `QA-EC2-IP`, `localhost` or `example.com` |
| Trigger: 401 | wrong username / API token in credential `qa-jenkins-api` |
| Trigger: 403 | `devops-trigger` lacks **Job/Build** or **Overall/Read** (step 9.2) |
| Trigger: 404 | wrong URL / job name (case-sensitive); the job must exist on the **QA** Jenkins |
| Trigger: 400 | the job is not parameterized yet: run `Sample-QA-Automation-Job` once by hand (step 7) so `APP_URL` is registered |
| Credential `qa-jenkins-api` not found | create it on the **DevOps** Jenkins (step 10.1), same exact ID |
| `Check application is reachable` fails on the QA job | app EC2 security group does not allow 8090 from the QA EC2 (step 4.3), or the site is down |
| `Permission denied (publickey)` on checkout | deploy key missing on the `bikerz-qa` repo or wrong credential (step 4.6) |
| `session not created` / Chrome not found | Chrome not installed for the QA EC2: re-run `setup-qa-server.sh` |
| `DevToolsActivePort file doesn't exist` / Chrome crashes | QA EC2 too small or out of memory: use `t3.medium`, check `free -h` (swap on) |
| Selenium cannot download chromedriver | QA EC2 has no internet access: check route/NAT and outbound rules |
| Tests fail with count mismatches | `bikes.json` changed; update the expected numbers (see section 0 note) |
| `No such DSL method 'allure'` | Allure plugin missing (step 5.1) |
| `Allure commandline 'allure' not found` | tool name must be exactly `allure` (step 5.2) |
| `No such DSL method 'zip'` / `'emailext'` | install *Pipeline Utility Steps* / *Email Extension* |
| No e-mail received | SMTP settings (step 5.3), spam folder, Jenkins console for mail errors |
| Static *Allure HTML Report* is blank | Jenkins blocks scripts in published HTML (CSP); use the **Allure Report** link, or ask your admin to relax CSP |
| `UnsupportedClassVersionError` | JDK older than 17 on the QA EC2 |
