#!/usr/bin/env bash
# One-time setup for the QA EC2 (Ubuntu 22.04 / 24.04). Installs:
#   JDK 17, Maven, Google Chrome, Jenkins (+ 2 GB swap for small instances)
# Run as the ubuntu user:   bash setup-qa-server.sh
set -euo pipefail

echo "== 1. Swap file (2 GB) so Jenkins + Chrome do not run out of memory =="
if ! swapon --show | grep -q swapfile; then
  sudo fallocate -l 2G /swapfile
  sudo chmod 600 /swapfile
  sudo mkswap /swapfile
  sudo swapon /swapfile
  echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
fi

echo "== 2. Packages: JDK 17, Maven, git, curl, unzip =="
sudo apt-get update -y
sudo apt-get install -y fontconfig openjdk-17-jdk maven git curl wget unzip gnupg ca-certificates

echo "== 3. Google Chrome (for headless Selenium tests) =="
if ! command -v google-chrome >/dev/null 2>&1; then
  wget -q -O /tmp/chrome.deb https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
  sudo apt-get install -y /tmp/chrome.deb
fi

echo "== 4. Jenkins =="
if ! command -v jenkins >/dev/null 2>&1 && [ ! -d /var/lib/jenkins ]; then
  sudo wget -q -O /usr/share/keyrings/jenkins-keyring.asc https://pkg.jenkins.io/debian-stable/jenkins.io-2023.key
  echo "deb [signed-by=/usr/share/keyrings/jenkins-keyring.asc] https://pkg.jenkins.io/debian-stable binary/" \
    | sudo tee /etc/apt/sources.list.d/jenkins.list >/dev/null
  sudo apt-get update -y
  sudo apt-get install -y jenkins
fi
sudo systemctl enable --now jenkins

echo "== 5. Let the jenkins user clone from GitHub over SSH (trust GitHub host key) =="
sudo -u jenkins mkdir -p /var/lib/jenkins/.ssh
sudo -u jenkins chmod 700 /var/lib/jenkins/.ssh
ssh-keyscan -H github.com 2>/dev/null | sudo -u jenkins tee -a /var/lib/jenkins/.ssh/known_hosts >/dev/null

echo "== Versions =="
java -version 2>&1 | head -1
mvn -v | head -1
google-chrome --version
sudo systemctl is-active jenkins

echo
echo "Initial Jenkins admin password:"
sudo cat /var/lib/jenkins/secrets/initialAdminPassword
echo
echo "Now open  http://<this-server-public-ip>:8080  (security group must allow port 8080 from your IP)."
