package com.bikerz.qa.utils;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/** Tiny HTTP helper for calling the Bikerz API directly. */
public final class ApiClient {
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10)).build();

    private ApiClient() {}

    public static HttpResponse<String> get(String path) {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(Config.baseUrl() + path))
                    .timeout(Duration.ofSeconds(15)).GET().build();
            return CLIENT.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            throw new RuntimeException("GET " + path + " failed: " + e.getMessage(), e);
        }
    }

    public static JsonElement json(String path) {
        return JsonParser.parseString(get(path).body());
    }
}
