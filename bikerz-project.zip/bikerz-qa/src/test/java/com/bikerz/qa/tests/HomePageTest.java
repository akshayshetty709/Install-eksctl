package com.bikerz.qa.tests;

import com.bikerz.qa.pages.HomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

@Epic("Bikerz")
@Feature("Catalogue page")
public class HomePageTest extends BaseTest {

    @Test(description = "Page title mentions Bikerz")
    public void titleContainsBikerz() {
        HomePage home = new HomePage(driver).open();
        assertTrue(home.title().contains("Bikerz"), "Unexpected title: " + home.title());
    }

    @Test(description = "All models are listed and match the count on the 'All' button")
    @Description("The number of cards shown must equal the number in the All (n) brand button")
    public void showsAllModels() {
        HomePage home = new HomePage(driver).open();
        assertTrue(home.totalFromAllButton() >= 27, "Expected at least 27 models");
        assertEquals(home.cardCount(), home.totalFromAllButton());
    }

    @Test(description = "Nine brand buttons are shown")
    public void showsNineBrands() {
        HomePage home = new HomePage(driver).open();
        assertEquals(home.brandButtonCount(), 9);
    }

    @Test(description = "Brand filter shows only models of that brand")
    public void brandFilterShowsOnlyThatBrand() {
        HomePage home = new HomePage(driver).open();
        home.selectBrand("ktm").waitForCardCount(3);
        home.cardBrands().forEach(b -> assertEquals(b.toUpperCase(), "KTM"));
    }

    @Test(description = "Search finds a model by name")
    public void searchFindsModel() {
        HomePage home = new HomePage(driver).open();
        home.search("classic 350").waitForCardCount(1);
        assertEquals(home.cardNames().get(0), "Classic 350");
    }

    @Test(description = "Search with no match shows the empty message")
    public void searchWithNoMatchShowsMessage() {
        HomePage home = new HomePage(driver).open();
        home.search("zzzzqqqq").waitForEmptyMessage();
        assertEquals(home.cardCount(), 0);
    }

    @Test(description = "Type filter 'Scooter' shows only scooters")
    public void scooterFilterShowsOnlyScooters() {
        HomePage home = new HomePage(driver).open();
        home.selectCategory("Scooter").waitForCardCount(2); // Jupiter 110 and Avenis 125
        home.cardTypes().forEach(t -> assertEquals(t, "Scooter"));
    }

    @Test(description = "Sort by price: low to high")
    public void priceSortLowToHigh() {
        HomePage home = new HomePage(driver).open();
        home.sortBy("price-asc").waitUntilPricesSorted(true);
    }

    @Test(description = "Sort by price: high to low")
    public void priceSortHighToLow() {
        HomePage home = new HomePage(driver).open();
        home.sortBy("price-desc").waitUntilPricesSorted(false);
    }
}
