package com.bikerz.qa.tests;

import com.bikerz.qa.pages.DetailPage;
import com.bikerz.qa.pages.HomePage;
import com.bikerz.qa.utils.ApiClient;
import com.google.gson.JsonArray;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

@Epic("Bikerz")
@Feature("Model details")
public class DetailTest extends BaseTest {

    @Test(description = "Classic 350 shows 4 versions with rupee prices and specs")
    public void classic350Details() {
        DetailPage detail = new HomePage(driver).open().openModel("re-classic-350");
        assertEquals(detail.title(), "Classic 350");
        assertEquals(detail.versionCount(), 4);
        detail.versionPrices().forEach(p -> assertTrue(p.startsWith("₹"), "Price not in rupees: " + p));
        assertTrue(detail.spec("Engine").orElse("").contains("349"), "Engine spec missing 349 cc");
        assertTrue(detail.spec("Max power").isPresent(), "Max power missing");
        assertTrue(detail.spec("Mileage (claimed/ARAI)").isPresent(), "Mileage missing");
        assertTrue(detail.imageLoaded(), "Image did not load");
    }

    @Test(description = "Details dialog can be closed")
    public void dialogCloses() {
        DetailPage detail = new HomePage(driver).open().openModel("ktm-390-duke");
        assertTrue(detail.isOpen());
        detail.close();
        assertFalse(detail.isOpen());
    }

    /** Every model in the catalogue must open with at least one version, specs and a loaded image. */
    @DataProvider(name = "models")
    public Object[][] models() {
        JsonArray bikes = ApiClient.json("/api/bikes").getAsJsonArray();
        Object[][] data = new Object[bikes.size()][1];
        for (int i = 0; i < bikes.size(); i++) {
            data[i][0] = bikes.get(i).getAsJsonObject().get("id").getAsString();
        }
        return data;
    }

    @Test(dataProvider = "models", description = "Every model opens with versions, specs and image")
    @Description("Smoke check across the whole catalogue")
    public void everyModelOpens(String modelId) {
        DetailPage detail = new HomePage(driver).open().openModel(modelId);
        assertTrue(detail.versionCount() >= 1, modelId + ": no versions");
        assertTrue(detail.specCount() >= 5, modelId + ": too few specs");
        assertTrue(detail.imageLoaded(), modelId + ": image not loaded");
    }
}
